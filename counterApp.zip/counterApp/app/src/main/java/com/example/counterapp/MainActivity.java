package com.example.counterapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView lblcounter;
    Button btnstart,btnstop;

    int counter=0;
    boolean running=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblcounter=(TextView)findViewById(R.id.lbl_txt);
        btnstart=(Button)findViewById(R.id.start);
        btnstop=(Button)findViewById(R.id.stop);

        btnstop.setOnClickListener(this);
        btnstart.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        if(view.equals(btnstart))
        {
            counter=0;
            running=true;
            new MyCounter().start();
        }
        else if(view.equals(btnstop)){
            running=false;
        }

    }


    Handler handler=new Handler()
    {
      public void handleMessage(Message m){
          lblcounter.setText(String.valueOf(m.what));
      }
    };

    class MyCounter extends Thread
    {
        public void run()
        {
            while(running)
            {
                counter++;
                handler.sendEmptyMessage(counter);

                try{
                    Thread.sleep(1000);
                }
                catch (Exception e){}
            }
        }
    }

}