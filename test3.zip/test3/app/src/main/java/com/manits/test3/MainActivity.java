package com.manits.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText t1,t2;
    Button b1;

    String re = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!])[A-Za-z\\d$@!]{8,}$";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1 = findViewById(R.id.e1);
        t2 = findViewById(R.id.p2);
        t1.setText("");
        t2.setText("");
        b1 = findViewById(R.id.b1);
        b1.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String user = t1.getText().toString();
        String pass = t2.getText().toString();
        if(validate(pass)){
            Bundle bundle = new Bundle();
            bundle.putString("u1",user);
            bundle.putString("p1",pass);
            Intent intent = new Intent(this,Login.class);
            intent.putExtra("data", bundle);
            startActivity(intent);
        }else{
            Toast.makeText(this, "Invalid Password Type", Toast.LENGTH_SHORT).show();
        }
    }
    public Boolean validate(String password){
        Pattern pattern = Pattern.compile(re);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }
}