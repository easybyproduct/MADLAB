package com.manits.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity implements View.OnClickListener {
    EditText e3,e4;
    Button b2;
    int count = 0;

    String user1, pass1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e3 = findViewById(R.id.e3);
        e4 = findViewById(R.id.e4);
        e3.setText("");
        e4.setText("");
        b2 = findViewById(R.id.b1);
        b2.setOnClickListener(this);
        Bundle bundle = getIntent().getBundleExtra("data");
        user1 = bundle.getString("u1");
        pass1 = bundle.getString("p1");
    }

    @Override
    public void onClick(View view) {
        String user = e3.getText().toString();
        String pass = e4.getText().toString();
        if(user.equals(user1)&&pass.equals(pass1)){
            Toast.makeText(this, "Login Success", Toast.LENGTH_SHORT).show();
        }else{
            count++;
            if(count==3){
                b2.setEnabled(false);
                Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this, "Login Failed:"+count+" attempts", Toast.LENGTH_SHORT).show();
            }
        }
    }
}