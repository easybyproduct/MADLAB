package com.example.phoneapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, bCall, bSave, btnClr;
    EditText e1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.btn1);
        b1.setOnClickListener(this);
        b2 = findViewById(R.id.btn2);
        b2.setOnClickListener(this);
        b3 = findViewById(R.id.btn3);
        b3.setOnClickListener(this);
        b4 = findViewById(R.id.btn4);
        b4.setOnClickListener(this);
        b5 = findViewById(R.id.btn5);
        b5.setOnClickListener(this);
        b6 = findViewById(R.id.btn6);
        b6.setOnClickListener(this);
        b7 = findViewById(R.id.btn7);
        b7.setOnClickListener(this);
        b8 = findViewById(R.id.btn8);
        b8.setOnClickListener(this);
        b9 = findViewById(R.id.btn9);
        b9.setOnClickListener(this);
        b0 = findViewById(R.id.btn0);
        b0.setOnClickListener(this);
        bSave = findViewById(R.id.btnSave);
        bSave.setOnClickListener(this);
        bCall = findViewById(R.id.btnCall);
        bCall.setOnClickListener(this);
        btnClr = findViewById(R.id.BtnClr);
        btnClr.setOnClickListener(this);
        e1 = findViewById(R.id.eT);
        e1.setText("");
    }

    @Override
    public void onClick(View view) {
        if(view.equals(b1))
            e1.append("1");
        if(view.equals(b2))
            e1.append("2");
        if(view.equals(b3))
            e1.append("3");
        if(view.equals(b4))
            e1.append("4");
        if(view.equals(b5))
            e1.append("5");
        if(view.equals(b6))
            e1.append("6");
        if(view.equals(b7))
            e1.append("7");
        if(view.equals(b8))
            e1.append("8");
        if(view.equals(b9))
            e1.append("9");
        if(view.equals(b0))
            e1.append("0");
        if(view.equals(bSave)){
            Intent contactIntent = new Intent(ContactsContract.Intents.Insert.ACTION);
            contactIntent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            contactIntent.putExtra(ContactsContract.Intents.Insert.NAME,"Unknown");
            contactIntent.putExtra(ContactsContract.Intents.Insert.PHONE,e1.getText().toString());
            startActivity(contactIntent);
        }
        if(view.equals(bCall)){
            String text = e1.getText().toString();
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:"+text));
            startActivity(intent);
        }
        if(view.equals(btnClr)){
            String text = e1.getText().toString();
            if(text.length()>0){
                e1.setText(text.substring(0, text.length()-1));
            }else {
                e1.setText("");
            }

}}}